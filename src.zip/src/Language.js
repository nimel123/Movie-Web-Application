export const languagedata=[
    "-Select Language-","English", "Mandarin Chinese", "Hindi", "Spanish", "French", "Arabic", "Bengali",
    "Russian", "Portuguese", "Indonesian", "Urdu", "German", "Japanese", "Swahili",
    "Marathi", "Telugu", "Turkish", "Tamil", "Korean", "Vietnamese", "Italian", "Polish",
    "Romanian", "Dutch", "Greek"
]
    