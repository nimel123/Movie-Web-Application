export const genredata=[
    '-Select Genre-',
    "Action", "Adventure", "Comedy", "Drama", "Fantasy", "Horror", "Mystery", "Romance",
    "Science Fiction", "Thriller", "Animation", "Biography", "Crime", "Documentary",
    "Family", "Film Noir", "History", "Music", "Musical", "Sport", "War", "Western"

]
